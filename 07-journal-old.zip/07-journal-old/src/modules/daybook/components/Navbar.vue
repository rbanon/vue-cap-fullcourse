<template>
    <nav class="navbar bg-primary">
        <a class="navbar-brand text-white">
            <img src="@/assets/logo.png" alt="View Logo" class="d-inline-block align-text-top mx-2" height="24">
            Daybook
        </a>
        
        <div class="d-flex">
            <button class="btn btn-outline-info mx-2">
                <i class="fa fa-sign-out-alt"></i>
            </button>
        </div>
    </nav>
</template>